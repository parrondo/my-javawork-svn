/*   */ package com.dukascopy.charts.data.datacache.pnf;
/*   */ 
/*   */ public abstract class PointAndFigureLiveFeedAdapter
/*   */   implements IPointAndFigureLiveFeedListener
/*   */ {
/*   */   public void newPriceData(PointAndFigureData pointAndFigure)
/*   */   {
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.pnf.PointAndFigureLiveFeedAdapter
 * JD-Core Version:    0.6.0
 */