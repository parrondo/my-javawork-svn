package com.dukascopy.charts.data.datacache.rangebar;

import com.dukascopy.charts.data.datacache.TickData;
import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationCreator;

public abstract interface IPriceRangeCreator extends IPriceAggregationCreator<PriceRangeData, TickData, IPriceRangeLiveFeedListener>
{
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.rangebar.IPriceRangeCreator
 * JD-Core Version:    0.6.0
 */