/*    */ package com.dukascopy.charts.data.datacache;
/*    */ 
/*    */ public class DataCacheException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public DataCacheException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DataCacheException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public DataCacheException(Throwable cause) {
/* 17 */     super(cause);
/*    */   }
/*    */ 
/*    */   public DataCacheException(String message, Throwable cause) {
/* 21 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.DataCacheException
 * JD-Core Version:    0.6.0
 */