/*    */ package com.dukascopy.charts.data.datacache.intraperiod.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*    */ 
/*    */ public class LastPointAndFigureLiveFeedListener extends LastAbstractPriceAggregationLiveFeedListener<PointAndFigureData>
/*    */   implements IPointAndFigureLiveFeedListener
/*    */ {
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.intraperiod.listener.LastPointAndFigureLiveFeedListener
 * JD-Core Version:    0.6.0
 */