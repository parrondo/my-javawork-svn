/*    */ package com.dukascopy.charts.data.datacache.intraperiod.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*    */ 
/*    */ public class LastPriceRangeLiveFeedListener extends LastAbstractPriceAggregationLiveFeedListener<PriceRangeData>
/*    */   implements IPriceRangeLiveFeedListener
/*    */ {
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.intraperiod.listener.LastPriceRangeLiveFeedListener
 * JD-Core Version:    0.6.0
 */