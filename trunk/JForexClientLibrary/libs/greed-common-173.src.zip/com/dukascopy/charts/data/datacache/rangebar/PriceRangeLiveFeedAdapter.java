/*   */ package com.dukascopy.charts.data.datacache.rangebar;
/*   */ 
/*   */ public abstract class PriceRangeLiveFeedAdapter
/*   */   implements IPriceRangeLiveFeedListener
/*   */ {
/*   */   public void newPriceData(PriceRangeData priceRange)
/*   */   {
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.rangebar.PriceRangeLiveFeedAdapter
 * JD-Core Version:    0.6.0
 */