/*    */ package com.dukascopy.charts.data.datacache.intraperiod.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.renko.IRenkoLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.renko.RenkoData;
/*    */ 
/*    */ public class LastRenkoLiveFeedListener extends LastAbstractPriceAggregationLiveFeedListener<RenkoData>
/*    */   implements IRenkoLiveFeedListener
/*    */ {
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.intraperiod.listener.LastRenkoLiveFeedListener
 * JD-Core Version:    0.6.0
 */