/*   */ package com.dukascopy.charts.data.datacache.tickbar;
/*   */ 
/*   */ public abstract class TickBarLiveFeedAdapter
/*   */   implements ITickBarLiveFeedListener
/*   */ {
/*   */   public void newPriceData(TickBarData tickBar)
/*   */   {
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.tickbar.TickBarLiveFeedAdapter
 * JD-Core Version:    0.6.0
 */