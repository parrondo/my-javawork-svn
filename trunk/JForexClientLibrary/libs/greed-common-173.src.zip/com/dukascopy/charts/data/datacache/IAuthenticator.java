package com.dukascopy.charts.data.datacache;

public abstract interface IAuthenticator
{
  public abstract String authenticate();
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.IAuthenticator
 * JD-Core Version:    0.6.0
 */