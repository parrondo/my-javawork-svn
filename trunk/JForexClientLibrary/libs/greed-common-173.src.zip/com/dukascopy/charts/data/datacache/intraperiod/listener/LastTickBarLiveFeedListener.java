/*    */ package com.dukascopy.charts.data.datacache.intraperiod.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.tickbar.TickBarData;
/*    */ 
/*    */ public class LastTickBarLiveFeedListener extends LastAbstractPriceAggregationLiveFeedListener<TickBarData>
/*    */   implements ITickBarLiveFeedListener
/*    */ {
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.intraperiod.listener.LastTickBarLiveFeedListener
 * JD-Core Version:    0.6.0
 */