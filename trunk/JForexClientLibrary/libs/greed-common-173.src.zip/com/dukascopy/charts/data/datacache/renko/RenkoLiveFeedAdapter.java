/*    */ package com.dukascopy.charts.data.datacache.renko;
/*    */ 
/*    */ public abstract class RenkoLiveFeedAdapter
/*    */   implements IRenkoLiveFeedListener
/*    */ {
/*    */   public void newPriceData(RenkoData renko)
/*    */   {
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.data.datacache.renko.RenkoLiveFeedAdapter
 * JD-Core Version:    0.6.0
 */