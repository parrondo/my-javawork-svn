package com.dukascopy.charts.listener;

import com.dukascopy.api.impl.CustIndicatorWrapper;

public abstract interface CustomIndicatorsActionListener
{
  public abstract void customIndicatorRegistered(CustIndicatorWrapper paramCustIndicatorWrapper);
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.listener.CustomIndicatorsActionListener
 * JD-Core Version:    0.6.0
 */