package com.dukascopy.charts.listener;

public abstract interface DisableEnableListener
{
  public abstract void disabled();

  public abstract void enabled();
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.listener.DisableEnableListener
 * JD-Core Version:    0.6.0
 */