package com.dukascopy.charts.math.dataprovider;

import com.dukascopy.api.Instrument;

public class OrdersDataChangeListenerAdapter
  implements OrdersDataChangeListener
{
  public void dataChanged(Instrument instrument, long from, long to)
  {
  }

  public void loadingStarted(Instrument instrument)
  {
  }

  public void loadingFinished(Instrument instrument)
  {
  }
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.math.dataprovider.OrdersDataChangeListenerAdapter
 * JD-Core Version:    0.6.0
 */