package com.dukascopy.charts.math.dataprovider;

public abstract interface ISynchronizeIndicators
{
  public abstract void synchronizeIndicators();
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.math.dataprovider.ISynchronizeIndicators
 * JD-Core Version:    0.6.0
 */