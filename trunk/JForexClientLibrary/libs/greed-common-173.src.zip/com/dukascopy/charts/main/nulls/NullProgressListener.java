package com.dukascopy.charts.main.nulls;

import com.dukascopy.charts.main.interfaces.ProgressListener;

public class NullProgressListener
  implements ProgressListener
{
  public void setProgress(boolean isProgress, boolean isLoadingOrders)
  {
  }
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.main.nulls.NullProgressListener
 * JD-Core Version:    0.6.0
 */