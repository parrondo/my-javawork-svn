package com.dukascopy.charts.main.interfaces;

public abstract interface ProgressListener
{
  public abstract void setProgress(boolean paramBoolean1, boolean paramBoolean2);
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.charts.main.interfaces.ProgressListener
 * JD-Core Version:    0.6.0
 */