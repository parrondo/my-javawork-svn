package com.dukascopy.calculator.graph;

import java.awt.Graphics2D;

public abstract class Element
{
  public abstract void draw(Model paramModel, View paramView, Graphics2D paramGraphics2D);
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.graph.Element
 * JD-Core Version:    0.6.0
 */