/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import java.awt.geom.Point2D.Double;
/*    */ 
/*    */ public class Point extends Point2D.Double
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public Point()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Point(double x, double y)
/*    */   {
/* 19 */     super(x, y);
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.graph.Point
 * JD-Core Version:    0.6.0
 */