/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ public class Log extends Monadic
/*   */ {
/*   */   public Log(Expression expression)
/*   */   {
/* 9 */     super(new com.dukascopy.calculator.function.Log(), expression);
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.expression.Log
 * JD-Core Version:    0.6.0
 */