/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ public class Exp extends Monadic
/*   */ {
/*   */   public Exp(Expression expression)
/*   */   {
/* 5 */     super(new com.dukascopy.calculator.function.Exp(), expression);
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.expression.Exp
 * JD-Core Version:    0.6.0
 */