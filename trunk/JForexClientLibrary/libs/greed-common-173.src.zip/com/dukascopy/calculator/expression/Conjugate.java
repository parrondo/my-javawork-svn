/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ public class Conjugate extends Monadic
/*   */ {
/*   */   public Conjugate(Expression expression)
/*   */   {
/* 5 */     super(new com.dukascopy.calculator.function.Conjugate(), expression);
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.expression.Conjugate
 * JD-Core Version:    0.6.0
 */