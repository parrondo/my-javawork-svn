/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ public class Ln extends Monadic
/*   */ {
/*   */   public Ln(Expression expression)
/*   */   {
/* 5 */     super(new com.dukascopy.calculator.function.Ln(), expression);
/*   */   }
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.expression.Ln
 * JD-Core Version:    0.6.0
 */