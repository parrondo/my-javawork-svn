/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Left extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "&#8592;" };
/*    */ 
/*    */   public Left()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.move.caret.left.left.arrow";
/* 12 */     this.fshortcut = '\000';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Left
 * JD-Core Version:    0.6.0
 */