/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class RParen extends PObject
/*    */ {
/* 20 */   private static final String[] fname = { ")" };
/*    */ 
/*    */   public RParen()
/*    */   {
/* 12 */     this.ftooltip = "sc.calculator.right.parenthesis.bracket";
/* 13 */     this.fshortcut = ')';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 17 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.RParen
 * JD-Core Version:    0.6.0
 */