/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Oct extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "O", "c", "t" };
/*    */ 
/*    */   public Oct()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.change.base.to.octal";
/* 12 */     this.fshortcut = 'O';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Oct
 * JD-Core Version:    0.6.0
 */