/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ public class Uplus extends RFunction
/*    */ {
/* 38 */   private static final String[] fname = { "+" };
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 22 */     return x;
/*    */   }
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 31 */     return x;
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 35 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Uplus
 * JD-Core Version:    0.6.0
 */