package com.dukascopy.calculator.function;

import com.dukascopy.calculator.OObject;

public abstract class RFunction extends SFunction
{
  public abstract double function(double paramDouble);

  public abstract OObject function(OObject paramOObject);
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.RFunction
 * JD-Core Version:    0.6.0
 */