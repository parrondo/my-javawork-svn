/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class SigmaPlus extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "&#931;", "+" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.SigmaPlus
 * JD-Core Version:    0.6.0
 */