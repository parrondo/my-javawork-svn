/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Right extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "&#8594;" };
/*    */ 
/*    */   public Right()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.move.caret.right.right.arrow";
/* 12 */     this.fshortcut = '\000';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Right
 * JD-Core Version:    0.6.0
 */