/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class I extends PObject
/*    */ {
/*    */   public static final String I = "i";
/* 23 */   private static final String[] fname = { "i" };
/*    */ 
/*    */   public I()
/*    */   {
/* 15 */     this.ftooltip = "i";
/* 16 */     this.fshortcut = 'j';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 20 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.I
 * JD-Core Version:    0.6.0
 */