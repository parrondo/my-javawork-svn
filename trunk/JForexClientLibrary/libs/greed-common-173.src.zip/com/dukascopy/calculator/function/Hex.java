/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Hex extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "H", "e", "x" };
/*    */ 
/*    */   public Hex()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.change.base.to.hexadecimal";
/* 12 */     this.fshortcut = 'H';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Hex
 * JD-Core Version:    0.6.0
 */