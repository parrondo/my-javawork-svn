/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Bin extends PObject
/*    */ {
/* 22 */   private static final String[] fname = { "B", "i", "n" };
/*    */ 
/*    */   public Bin()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.change.base.to.binary";
/* 15 */     this.fshortcut = 'B';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 19 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Bin
 * JD-Core Version:    0.6.0
 */