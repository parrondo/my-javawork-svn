/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Pol extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "P", "o", "l" };
/*    */ 
/*    */   public Pol()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.change.to.from.complex.polar.notation";
/* 12 */     this.fshortcut = 'o';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Pol
 * JD-Core Version:    0.6.0
 */