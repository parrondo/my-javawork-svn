/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class STO extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "S", "T", "O" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.STO
 * JD-Core Version:    0.6.0
 */