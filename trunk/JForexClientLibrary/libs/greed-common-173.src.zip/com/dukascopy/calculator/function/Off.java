/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Off extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "O", "F", "F" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Off
 * JD-Core Version:    0.6.0
 */