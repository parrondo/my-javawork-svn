/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Graph extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "G", "r", "a", "p", "h" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Graph
 * JD-Core Version:    0.6.0
 */