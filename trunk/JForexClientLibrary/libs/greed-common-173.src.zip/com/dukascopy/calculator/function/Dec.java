/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Dec extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "D", "e", "c" };
/*    */ 
/*    */   public Dec()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.change.base.to.decimal";
/* 12 */     this.fshortcut = 'D';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Dec
 * JD-Core Version:    0.6.0
 */