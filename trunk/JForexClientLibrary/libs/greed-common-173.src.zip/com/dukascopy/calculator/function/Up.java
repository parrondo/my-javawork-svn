/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Up extends PObject
/*    */ {
/* 19 */   private static final String[] fname = { "&#8593;" };
/*    */ 
/*    */   public Up()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.previous.expression.up.arrow";
/* 12 */     this.fshortcut = '\000';
/*    */   }
/*    */ 
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Up
 * JD-Core Version:    0.6.0
 */