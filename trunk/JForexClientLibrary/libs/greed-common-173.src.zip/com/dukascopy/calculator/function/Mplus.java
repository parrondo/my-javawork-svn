/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Mplus extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "M", "+" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Mplus
 * JD-Core Version:    0.6.0
 */