/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ public class Scl extends PObject
/*    */ {
/* 15 */   private static final String[] fname = { "S", "c", "l" };
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.function.Scl
 * JD-Core Version:    0.6.0
 */