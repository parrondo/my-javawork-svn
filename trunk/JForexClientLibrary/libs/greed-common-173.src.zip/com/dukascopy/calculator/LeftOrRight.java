/*   */ package com.dukascopy.calculator;
/*   */ 
/*   */ public enum LeftOrRight
/*   */ {
/* 8 */   NEITHER, LEFT, RIGHT, BOTH;
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.LeftOrRight
 * JD-Core Version:    0.6.0
 */