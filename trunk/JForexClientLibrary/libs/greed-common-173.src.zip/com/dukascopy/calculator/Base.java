/*   */ package com.dukascopy.calculator;
/*   */ 
/*   */ public enum Base
/*   */ {
/* 9 */   BINARY, OCTAL, DECIMAL, HEXADECIMAL;
/*   */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.Base
 * JD-Core Version:    0.6.0
 */