/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ public class Error extends OObject
/*    */ {
/*    */   private String s;
/*    */ 
/*    */   public Error(String s)
/*    */   {
/* 15 */     this.s = s;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 23 */     return this.s;
/*    */   }
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.Error
 * JD-Core Version:    0.6.0
 */