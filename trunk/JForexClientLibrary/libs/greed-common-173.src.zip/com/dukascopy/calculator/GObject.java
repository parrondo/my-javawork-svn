package com.dukascopy.calculator;

public abstract class GObject
{
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.calculator.GObject
 * JD-Core Version:    0.6.0
 */