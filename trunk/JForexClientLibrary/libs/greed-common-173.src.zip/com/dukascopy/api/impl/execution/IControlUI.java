package com.dukascopy.api.impl.execution;

import javax.swing.JComponent;

public abstract interface IControlUI
{
  public abstract void setControlField(JComponent paramJComponent, boolean paramBoolean)
    throws Exception;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.execution.IControlUI
 * JD-Core Version:    0.6.0
 */