package com.dukascopy.api.impl.talib;

import com.tictactec.ta.lib.meta.annotation.OptInputParameterType;

public class OptInputParameterInfoHolder extends Holder
{
  public String paramName;
  public String displayName;
  public int flags;
  public OptInputParameterType type;
  public Class<? extends Object> dataSet;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.OptInputParameterInfoHolder
 * JD-Core Version:    0.6.0
 */