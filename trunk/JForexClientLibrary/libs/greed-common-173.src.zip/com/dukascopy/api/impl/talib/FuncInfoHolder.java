/*    */ package com.dukascopy.api.impl.talib;
/*    */ 
/*    */ public class FuncInfoHolder extends Holder
/*    */ {
/*    */   public String name;
/*    */   public String group;
/* 13 */   public String hint = "";
/* 14 */   public String helpFile = "";
/*    */   public int flags;
/*    */   public int nbInput;
/*    */   public int nbOptInput;
/*    */   public int nbOutput;
/*    */ }

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.FuncInfoHolder
 * JD-Core Version:    0.6.0
 */