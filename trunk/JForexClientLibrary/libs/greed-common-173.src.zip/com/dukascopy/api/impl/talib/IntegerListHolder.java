package com.dukascopy.api.impl.talib;

public class IntegerListHolder extends Holder
{
  public String paramName;
  public int defaultValue;
  public int[] value;
  public String[] string;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.IntegerListHolder
 * JD-Core Version:    0.6.0
 */