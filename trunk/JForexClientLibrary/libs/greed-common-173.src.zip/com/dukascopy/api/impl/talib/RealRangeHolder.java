package com.dukascopy.api.impl.talib;

public class RealRangeHolder extends Holder
{
  public String paramName;
  public double defaultValue;
  public double min;
  public double max;
  public int precision;
  public double suggested_start;
  public double suggested_end;
  public double suggested_increment;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.RealRangeHolder
 * JD-Core Version:    0.6.0
 */