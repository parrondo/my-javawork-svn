package com.dukascopy.api.impl.talib;

import com.tictactec.ta.lib.meta.annotation.OutputParameterType;

public class OutputParameterInfoHolder extends Holder
{
  public OutputParameterType type;
  public String paramName;
  public int flags;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.OutputParameterInfoHolder
 * JD-Core Version:    0.6.0
 */