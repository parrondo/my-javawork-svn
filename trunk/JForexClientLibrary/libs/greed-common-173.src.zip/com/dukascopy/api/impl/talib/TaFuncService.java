package com.dukascopy.api.impl.talib;

import com.dukascopy.api.impl.TaLibMetaData;

public abstract interface TaFuncService
{
  public abstract void execute(TaLibMetaData paramTaLibMetaData)
    throws Exception;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.TaFuncService
 * JD-Core Version:    0.6.0
 */