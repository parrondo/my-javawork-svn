package com.dukascopy.api.impl;

public abstract interface TimedData
{
  public abstract long getTime();

  public abstract void setTime(long paramLong);
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.TimedData
 * JD-Core Version:    0.6.0
 */