package com.dukascopy.api.impl.talib;

public class IntegerRangeHolder extends Holder
{
  public String paramName;
  public int defaultValue;
  public int min;
  public int max;
  public int suggested_start;
  public int suggested_end;
  public int suggested_increment;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.IntegerRangeHolder
 * JD-Core Version:    0.6.0
 */