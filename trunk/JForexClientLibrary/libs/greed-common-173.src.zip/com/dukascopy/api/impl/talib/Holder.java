package com.dukascopy.api.impl.talib;

public class Holder
{
  public Class annotationType;
}

/* Location:           G:\javawork\JForexClientLibrary\libs\greed-common-173.jar
 * Qualified Name:     com.dukascopy.api.impl.talib.Holder
 * JD-Core Version:    0.6.0
 */